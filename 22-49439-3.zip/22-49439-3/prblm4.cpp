#include<iostream>
using namespace std;

int main()
{

    int arr1[7]={5,7,5,4,7,7,4};

    int count=0;
    int number;

    cout<<"Enter number to search :"<<endl;
    cin>>number;

    for(int i=0;i<7;i++)
    {
    if(arr1[i]==number)
    {
        count++;
    }
    }

    cout<<number<<"  has been displayed "<<count<<" times"<<endl;















return 0;
}

