#include<iostream>
using namespace std;

int main()
{

int arr1[4];
int arr2[6];

    cout<<"Enter arr1 :"<<endl;
    for(int i=0;i<4;i++)
    {
        cin>>arr1[i];
    }

    cout<<"Arr1 :"<<endl;
    for(int i=0;i<4;i++)
    {
        cout<<arr1[i]<<" ";
    }
    cout<<endl;


    cout<<"Enter arr2 :"<<endl;
    for(int i=0;i<6;i++)
    {
        cin>>arr2[i];
    }

    cout<<"Arr2 :"<<endl;
    for(int i=0;i<6;i++)
    {
        cout<<arr2[i]<<" ";
    }
    cout<<endl;



    for(int i=0;i<4;i++)
    {
        for(int j=0;j<6;j++)
    if(arr1[i]==arr2[j])
       {
         cout<<"Common element :  "<<arr2[j]<<" ";
       }

        }

        bool isCommon=false;


        for(int i=0;i<4;i++)
    {
        for(int j=0;j<6;j++)
    if(arr1[i]!=arr2[j])
       {
           isCommon=false;

       }
       else if(arr1[i]==arr2[j])
       {
       isCommon=true;
       }

        }

         cout<<endl;
        cout<<"is there a common value ?:"<<isCommon;


















 return 0;
}
