#include<iostream>
using namespace std;

int main()
{
    int arr1[4];
    int arr2[6];
    int arr3[10];

    cout<<"Enter arr1 :"<<endl;
    for(int i=0;i<4;i++)
    {
        cin>>arr1[i];
    }

    cout<<"Arr1 :"<<endl;
    for(int i=0;i<4;i++)
    {
        cout<<arr1[i]<<" ";
    }
    cout<<endl;


    cout<<"Enter arr2 :"<<endl;
    for(int i=0;i<6;i++)
    {
        cin>>arr2[i];
    }

    cout<<"Arr2 :"<<endl;
    for(int i=0;i<6;i++)
    {
        cout<<arr2[i]<<" ";
    }
    cout<<endl;

    int arr1size=sizeof(arr1) / sizeof(arr1[0]);
    int arr2size=sizeof(arr2) / sizeof(arr2[0]);
    int arr3size=arr1size + arr2size;

    for(int i=0;i<arr1size;i++)
    {
    arr3[i]=arr1[i];
    }
    for(int i=0;i<arr2size;i++)
    {
    arr3[arr1size+i]=arr2[i];
    }
    cout<<"Merged array :"<<endl;

    for(int i=0;i<arr3size;i++)
    {
    cout<<arr3[i]<<" ";

    }cout<<endl;
    cout<<"Merged array in reverse :"<<endl;
    for(int i=arr3size-1;i>=0;i--)
    {
    cout<<arr3[i]<<" ";

    }cout<<endl;










return 0;


}
